/**
 * Created by Debasis-01 on 7/30/2015.
 */

function setValue(val){
    $('#username').val(val);
    //$('.username').text(val);
    //alert(val);
}
function add_userdevice_with_session(val){
    //alert(val);
    $('#deviceid').val(val);
    //$('.deviceid').text(val);
}
